# Touchline automatic Premier League site

The site refreshes fixtures, completed scores, standings and estimated match probabilities every six hours, then publishes the refreshed page to GitHub Pages. GitHub Actions runs the update; the browser displays the latest generated snapshot. The included model uses a Poisson goal estimate based on each team's most recent league results. Predictions are estimates, not guarantees.

## One-time setup

1. Create a free account at [football-data.org](https://www.football-data.org/client/register) and copy your API token. The provider's free plan includes fixtures, delayed scores and league tables, with a request limit of 10 calls per minute; this workflow makes two calls per refresh.
2. Create a **public** GitHub repository named `touchline`, then upload the contents of this folder, including the `.github` directory. Keep the default branch named `main`.
3. In the GitHub repository, open **Settings → Secrets and variables → Actions → New repository secret**. Name it `FOOTBALL_DATA_TOKEN` and paste the API token as the value. The token stays on GitHub Actions and is not sent to site visitors.
4. Open **Settings → Pages** and choose **GitHub Actions** as the build and deployment source.
5. Open **Actions → Refresh football data and publish site → Run workflow** once. After it succeeds, open **Settings → Pages** for the site address.

After setup, pushes to `main` and the six-hour schedule refresh and republish the site automatically. GitHub's scheduled workflows can start late during busy periods, so refresh times are approximate. The free API can delay scores and does not provide live scores on its free plan.

## Local preview

Open `site/index.html` directly to see the layout. Live data appears after running `node scripts/update.mjs` with `FOOTBALL_DATA_TOKEN` set. A local preview must be served over HTTP, for example `npx serve site`, because browsers block `fetch()` from a `file://` page.

## Model and coverage

The model derives expected goals from recent completed league results and calculates home/draw/away probabilities with a Poisson distribution. It is a transparent baseline, not a trained or independently validated forecasting system. The API token is required for scheduled updates. If a refresh fails, GitHub Actions reports the failure and the previously published snapshot remains available.
